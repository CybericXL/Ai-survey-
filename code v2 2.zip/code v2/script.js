;document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes('survey.html')) {
        setupSurvey();
    } else if (window.location.pathname.includes('result.html')) {
        displayResults();
    }
});

const questions = [
    { 
        question: "Do you enjoy social gatherings?", 
        scores: [
            { trait: "Extrovert", weight: 10 },
            { trait: "Introvert", weight: -5 },
            { trait: "ConfidentSpeaker", weight: 7 },
            { trait: "TeamPlayer", weight: 5 },
            { trait: "Empathetic", weight: 2 }
        ]
    },
    { 
        question: "Do you often think about the future?", 
        scores: [
            { trait: "Visionary", weight: 10 },
            { trait: "Analytical", weight: 6 },
            { trait: "Organized", weight: 4 },
            { trait: "Learner", weight: 8 },
            { trait: "Patient", weight: -5 }
        ]
    },
    { 
        question: "Do you prefer books over parties?", 
        scores: [
            { trait: "Introvert", weight: 10 },
            { trait: "Creative", weight: 6 },
            { trait: "Learner", weight: 7 },
            { trait: "Patient", weight: 4 },
            { trait: "Extrovert", weight: -2 }
        ]
    },
    { 
        question: "Do you like to take charge in group situations?", 
        scores: [
            { trait: "Leader", weight: 10 },
            { trait: "ConfidentSpeaker", weight: 8 },
            { trait: "Extrovert", weight: 6 },
            { trait: "TeamPlayer", weight: 5 }
        ]
    },
    { 
        question: "Are you good at multitasking?", 
        scores: [
            { trait: "Multitasker", weight: 10 },
            { trait: "Organized", weight: 6 },
            { trait: "Adventurous", weight: 5 },
            { trait: "EarlyRiser", weight: 4 }
        ]
    },
    { 
        question: "Do you enjoy public speaking?", 
        scores: [
            { trait: "ConfidentSpeaker", weight: 10 },
            { trait: "Extrovert", weight: 7 },
            { trait: "Empathetic", weight: 3 },
            { trait: "Leader", weight: 5 }
        ]
    },
    { 
        question: "Do you prefer outdoor activities?", 
        scores: [
            { trait: "Adventurous", weight: 10 },
            { trait: "IndoorOutdoor", weight: 5 },
            { trait: "Creative", weight: 4 },
            { trait: "EarlyRiser", weight: 3 }
        ]
    },
    { 
        question: "Are you a creative thinker?", 
        scores: [
            { trait: "Creative", weight: 10 },
            { trait: "Visionary", weight: 2 },
            { trait: "Analytical", weight: 4 },
            { trait: "Learner", weight: 5 }
        ]
    },
    { 
        question: "Do you enjoy learning new things?", 
        scores: [
            { trait: "Learner", weight: 10 },
            { trait: "Visionary", weight: 2 },
            { trait: "Creative", weight: 4 },
            { trait: "Adventurous", weight: 3 }
        ]
    },
    { 
        question: "Are you a patient person?", 
        scores: [
            { trait: "Patient", weight: 10 },
            { trait: "Empathetic", weight: 5 },
            { trait: "Introvert", weight: 4 },
            { trait: "Analytical", weight: 3 }
        ]
    },
    { 
        question: "Do you prefer solo activities?", 
        scores: [
            { trait: "Introvert", weight: 10 },
            { trait: "Extrovert", weight: -5 },
            { trait: "TeamPlayer", weight: 6 },
            { trait: "Leader", weight: 4 }
        ]
    },
    { 
        question: "Are you detail-oriented?", 
        scores: [
            { trait: "Organized", weight: 10 },
            { trait: "Analytical", weight: 8 },
            { trait: "Patient", weight: 6 },
            { trait: "Visionary", weight: 4 }
        ]
    },
    { 
        question: "Do you enjoy taking risks?", 
        scores: [
            { trait: "RiskTaker", weight: 10 },
            { trait: "Adventurous", weight: 7 },
            { trait: "ConfidentSpeaker", weight: 5 },
            { trait: "Leader", weight: 6 }
        ]
    },
    { 
        question: "Do you prefer working independently?", 
        scores: [
            { trait: "Introvert", weight: 10 },
            { trait: "Analytical", weight: 7 },
            { trait: "Organized", weight: 5 },
            { trait: "Extrovert", weight: -5 }
        ]
    },
    { 
        question: "Are you good at handling multiple tasks at once?", 
        scores: [
            { trait: "Multitasker", weight: 10 },
            { trait: "Organized", weight: 8 },
            { trait: "EarlyRiser", weight: 6 },
            { trait: "TeamPlayer", weight: 5 }
        ]
    },
    { 
        question: "Do you have a passion for learning?", 
        scores: [
            { trait: "Learner", weight: 10 },
            { trait: "Visionary", weight: 4 },
            { trait: "Creative", weight: 4 },
            { trait: "Analytical", weight: 3 }
        ]
    },
    { 
        question: "Do you find it easy to empathize with others?", 
        scores: [
            { trait: "Empathetic", weight: 10 },
            { trait: "Patient", weight: 6 },
            { trait: "TeamPlayer", weight: 4 },
            { trait: "Leader", weight: 3 },
            { trait: "Extrovert", weight: 6 }
        ]
    },
    { 
        question: "Are you an early riser?", 
        scores: [
            { trait: "EarlyRiser", weight: 10 },
            { trait: "Organized", weight: 6 },
            { trait: "Visionary", weight: 2 },
            { trait: "Multitasker", weight: 5 }
        ]
    },
    { 
        question: "Do you adapt quickly to new situations?", 
        scores: [
            { trait: "Adventurous", weight: 8 },
            { trait: "RiskTaker", weight: 7 },
            { trait: "EarlyRiser", weight: 4 },
            { trait: "Learner", weight: 10 }
        ]
    }
];

const traitExplanations = {
    "Extrovert": "You thrive in social settings and enjoy interacting with others.",
    "Visionary": "You often think ahead and have a futuristic outlook.",
    "Introvert": "You prefer solitary activities and enjoy time spent alone.",
    "Leader": "You naturally take charge and lead others in group situations.",
    "Empathetic": "You easily understand and share the feelings of others.",
    "EarlyRiser": "Mornings are your prime time, and you're most productive then.",
    "Adventurous": "You love exploring new activities and aren't afraid of challenges.",
    "Organized": "You are methodical and like to plan things in detail.",
    "Analytical": "You excel at examining things and solving complex problems.",
    "RiskTaker": "You're not afraid to take chances and make bold moves.",
    "TeamPlayer": "Collaborating with others comes naturally to you.",
    "Multitasker": "Juggling multiple tasks at once is your forte.",
    "ConfidentSpeaker": "Public speaking is a strength of yours; you express yourself well.",
    "IndoorOutdoor": "You enjoy a mix of indoor and outdoor activities.",
    "Creative": "Innovative and original ideas are your strengths.",
    "Learner": "You have a passion for learning and acquiring new knowledge.",
    "Patient": "You have a high tolerance for difficult situations and remain calm."
};

function setupSurvey() {
    const surveyForm = document.getElementById('surveyForm');
    questions.forEach((q, index) => {
        const questionBlock = document.createElement('div');
        questionBlock.classList.add('question-block');
        questionBlock.innerHTML = `
            <p>${q.question}</p>
            ${generateResponseButtons(index)}
        `;
        surveyForm.appendChild(questionBlock);
        
        // Add event listeners to each response button
        const responseButtons = questionBlock.querySelectorAll('.response-btn');
        responseButtons.forEach((button, responseIndex) => {
            button.addEventListener('click', () => {
                selectResponse(button, index, responseIndex);
            });
        });
    });

    // Adding a submit button at the end of the survey
    const submitButton = document.createElement('button');
    submitButton.type = 'submit';
    submitButton.textContent = 'Finish Survey';
    submitButton.classList.add('submit-btn');
    surveyForm.appendChild(submitButton);

    surveyForm.addEventListener('submit', handleSurveySubmit);
}

function generateResponseButtons(questionIndex) {
    const responseGradients = [
        "linear-gradient(to bottom, darkgreen, lightgreen)", // Strongly Agree
        "linear-gradient(to bottom, lightgreen, yellow)", // Agree
        "linear-gradient(to bottom, yellow, orange)", // Neutral
        "linear-gradient(to bottom, orange, orangered)", // Disagree
        "linear-gradient(to bottom, orangered, darkred)" // Strongly Disagree
    ];

    const responseOptions = ["Strongly Agree", "Agree", "Neutral", "Disagree", "Strongly Disagree"];
    
    return responseOptions.map((option, index) => `
        <button type="button" class="response-btn" style="background: ${responseGradients[index]};">${option}</button>
    `).join('');
}

// ...

function selectResponse(button, questionIndex, responseIndex) {
    // Remove the 'selected' class from all response buttons within the same question
    const questionBlock = button.closest('.question-block');
    const responseButtons = questionBlock.querySelectorAll('.response-btn');
    responseButtons.forEach((btn) => {
        btn.classList.remove('selected');
    });

    // Add the 'selected' class to the clicked response button
    button.classList.add('selected');

    // Store the response index for the question in localStorage
    localStorage.setItem(`question${questionIndex}`, responseIndex);
}

function calculateDominantTrait() {
    const traitScores = {};

    // Initialize trait scores
    for (const trait in traitExplanations) {
        traitScores[trait] = 0;
    }

    // Calculate trait scores based on responses
    questions.forEach((q, index) => {
        const responseIndex = parseInt(localStorage.getItem(`question${index}`), 10);
        if (responseIndex !== null) {
            q.scores.forEach(score => {
                traitScores[score.trait] += score.weight * responseIndex;
            });
        }
    });

    // Determine the dominant trait
    let dominantTrait = "";
    let maxScore = -Infinity;
    for (const trait in traitScores) {
        if (traitScores[trait] > maxScore) {
            maxScore = traitScores[trait];
            dominantTrait = trait;
        }
    }

    return dominantTrait;
}

function displayResults() {
    const resultContainer = document.getElementById('result');
    const personality = calculateDominantTrait();
    localStorage.setItem('personality', personality);

    if (resultContainer && personality) {
        const traitExplanation = traitExplanations[personality];

        // Clear the container and set its styles
        resultContainer.innerHTML = '';
        resultContainer.style.textAlign = 'center';
        resultContainer.style.backgroundColor = 'rgba(233, 233, 233, 0.95)';
        resultContainer.style.borderRadius = '8px';
        resultContainer.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';

        // Create and append the centered title
        const title = document.createElement('h2');
        title.textContent = 'Your dominant personality trait is:';
        resultContainer.appendChild(title);

        // Create and append the personality trait
        const personalityTrait = document.createElement('h3');
        personalityTrait.textContent = personality;
        resultContainer.appendChild(personalityTrait);

        // Create and append the trait explanation
        const traitExplanationInfo = document.createElement('p');
        traitExplanationInfo.textContent = traitExplanation;
        resultContainer.appendChild(traitExplanationInfo);
    } else {
        resultContainer.innerText = 'No results to display. Please complete the survey.';
    }
}